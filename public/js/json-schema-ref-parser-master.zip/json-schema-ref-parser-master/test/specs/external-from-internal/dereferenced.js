"use strict";

module.exports =
{
  internal1: {
    test: {
      type: "string"
    }
  },
  internal2: {
    test: {
      type: "string"
    }
  },
  internal3: {
    test: {
      type: "string"
    }
  },
  internal4: {
    test: {
      type: "string"
    }
  },
  external1: {
    test: {
      type: "string"
    }
  },
  external2: {
    test: {
      type: "string"
    }
  }
};
