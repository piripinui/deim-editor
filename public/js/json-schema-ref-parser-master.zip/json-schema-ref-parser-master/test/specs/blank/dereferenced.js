"use strict";

module.exports = {
  json: undefined,
  yaml: undefined,
  text: "",
  binary: { type: "Buffer", data: []},
  unknown: undefined
};
